//--------------------------------------------------
//Function to convert a given time in seconds (integer) to a string 
// in hrs:mins:secs format
//--------------------------------------------------------
function convertToHrsMinsSecs(seconds)
{
	if(seconds != null  && seconds != 0)
	{
		mins =Math.floor(seconds/60);
		secs = Math.floor(seconds % 60);
		hrs = Math.floor(mins/60);
		mins = Math.floor(mins % 60);
		if(hrs < 10)
		{
			hrs = "0" + hrs;
		}
		if(mins < 10)
		{
			mins = "0" + mins;
		}
		if(secs < 10)
		{
			secs = "0" + secs;
		}
	
		return (hrs+ ":" + mins + ":" + secs);
	}
	else
	{
		return "00:00:00";
	}
}


//--------------------------------------------------
// Function to build a non-SQL like "IN" list from a multi-value
// selection parameter.
//--------------------------------------------------
function buildInList(param_name)
{
	var node_vals = "";
	var nodes = params[param_name];
	var num_nodes = reportContext.getParameterValue(param_name).length;

	/*
	 * Build the required string and return it.
	 */
	for( var idx = 0; idx < num_nodes; ++idx )
	{
		node_vals += nodes.value[idx];
		if( (idx + 1) < num_nodes )
		{
			node_vals += ", ";
		}
	}

	return (node_vals);
}

//--------------------------------------------------
// Function to build an "IN" list from a multi-value selection parameter.
//--------------------------------------------------
function buildInListSQL(param_name)
{
	var node_vals = "";
	var nodes = params[param_name];
	var num_nodes = reportContext.getParameterValue(param_name).length;

	/*
	 * Build the required string and return it.
	 */
	for( var idx = 0; idx < num_nodes; ++idx )
	{
		node_vals += "'" + nodes.value[idx] + "'";
		if( (idx + 1) < num_nodes )
		{
			node_vals += ",";
		}
	}

	return (node_vals);
}
